// the title
document.getElementById("title").innerHTML = "herePutTheTitleThatGonnaShowUP";

// the icon favicon
document.getElementById("image").href = "herePutTheUrlOfThePhoto";
// the name inthe table
document.getElementById("moviename").innerHTML = "newMovie";

// movie year and the year tooks u to specifie url in the table
document.getElementById("theyear").innerHTML = "PUTurlExample.(2019).";
document.getElementById("theyear").href = "../../Main/years/herePutTheYear/" ;

// the lang of the movie 
document.getElementById("lang").innerHTML = "addNewMovie";

// the country of the movie  
document.getElementById("country").innerHTML = "addNewMovie";

//the age allowed to watch
document.getElementById("age").innerHTML = "addNewMovie";

// here is trans or not 
document.getElementById("trans").innerHTML = "addNewMovie";

// here is the type u can put for type from a to d
document.getElementById("typea").innerHTML = "addNewMovie";
document.getElementById("typed").innerHTML = "addNewMovie"
document.getElementById("typec").innerHTML = "addNewMovie";
document.getElementById("typea").href = "../../Main/types/animation/";
document.getElementById("typed").href = "../../Main/types/action/"
document.getElementById("typec").href = "../../Main/types/advanture/";

// here u put the story  of the movie
document.getElementById("thestory").innerHTML = "addNewMovie";

// here put the movie img next to the table
document.getElementById("movieimg").src = "https://m.media-amazon.com/images/M/MV5BMmRmZDc2OGYtNTNiOC00ZjMxLTg4MzItZWE5ZDk4ZGQwZTEyXkEyXkFqcGdeQXVyNzEyMDQ1MDA@._V1_UY268_CR4,0,182,268_AL_.jpg";

/* here start the actor

!--the actors are sex and every one have actorjob and actorimg and actorname
and if u dont have the actor img then put this url on actorimg "../../Main/needed-photos/unkown-person.jfif"

*/

// the first actor a
document.getElementById("actornamea").innerHTML = "AddNewActor";
document.getElementById("actorjoba").innerHTML = "AddNewActor";
document.getElementById("actorimga").src = "../../Main/needed-photos/unkown-person.jfif";

// the first actor b
document.getElementById("actornameb").innerHTML = "AddNewActorا";
document.getElementById("actorjobb").innerHTML = "AddNewActor";
document.getElementById("actorimgb").src = "https://cdn.animenewsnetwork.com/thumbnails/crop150x150gH7/encyc/P90206-3280428979.1559114220.jpg";

// the first actor c
document.getElementById("actornamec").innerHTML = "AddNewActor";
document.getElementById("actorjobc").innerHTML = "AddNewActor";
document.getElementById("actorimgc").src = "../../Main/needed-photos/unkown-person.jfif";

// the first actor d
document.getElementById("actornamed").innerHTML = "AddNewActor";
document.getElementById("actorjobd").innerHTML = "AddNewActor";
document.getElementById("actorimgd").src = "https://m.media-amazon.com/images/M/MV5BNGFlZWIzMTQtZDkxMS00YTM0LTg4Y2QtMTgxN2MyMzUzMGUzXkEyXkFqcGdeQXVyMzM4MjM0Nzg@._V1_UY1200_CR120,0,630,1200_AL_.jpg";

// the first actor e
document.getElementById("actornamee").innerHTML = "AddNewActor";
document.getElementById("actorjobe").innerHTML = "AddNewActor";
document.getElementById("actorimge").src = "https://cdn.myanimelist.net/images/voiceactors/1/54010.jpg";

// the first actor f
document.getElementById("actornamef").innerHTML = "AddNewActor";
document.getElementById("actorjobf").innerHTML = "AddNewActor";
document.getElementById("actorimgf").src = "../../Main/needed-photos/unkown-person.jfif";

// here is the video trailer
document.getElementById("videotrailer").src = "like example https://www.youtube-nocookie.com/embed/xu8O8wYN-Ik";

// here u put the link for downloading the movie
document.getElementById("downloadlink").href = "like example https://mega.nz/file/vds3QSaI#maom3e3ht8BHqdBr0saI8cGC2rPajOn3vtXwu6GMAcs";

// here u put the url for movie to show it on a iframe
document.getElementById("videomovie").src = "like example https://mega.nz/embed/vds3QSaI#maom3e3ht8BHqdBr0saI8cGC2rPajOn3vtXwu6GMAcs";