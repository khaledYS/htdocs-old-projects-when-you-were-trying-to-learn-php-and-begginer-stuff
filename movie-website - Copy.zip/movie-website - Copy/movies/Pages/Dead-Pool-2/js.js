// the title
// document.getElementById("title").innerHTML = "DeadPool 2";

// the icon favicon
document.getElementById("image").href = "https://upload.wikimedia.org/wikipedia/ar/thumb/1/1a/Deadpool_two_ver15.jpg/260px-Deadpool_two_ver15.jpg";
// the name inthe table
document.getElementById("moviename").innerHTML = "DeadPool 2";

// movie year and the year tooks u to specifie url in the table
document.getElementById("theyear").innerHTML = "(2018)";
document.getElementById("theyear").href = "../../Main/years/2018/" ;

// the lang of the movie 
document.getElementById("lang").innerHTML = "الأنجليزية";

// the country of the movie  
document.getElementById("country").innerHTML = "الولايات المتحدة الأمريكية";

//the age allowed to watch
document.getElementById("age").innerHTML = "18+ يحتوي على مشاهد عنيفة أو فاضحة للحياء";

// here is trans or not 
document.getElementById("trans").innerHTML = "نعم مترجم إلى العربية";

// here is the type u can put for type from a to d
document.getElementById("typea").innerHTML = " *كوميدي* ";
document.getElementById("typed").innerHTML = " *أكشن* "
document.getElementById("typec").innerHTML = " *مغامرة* ";
document.getElementById("typea").href = "../../Main/types/comedy/";
document.getElementById("typed").href = "../../Main/types/action/"
document.getElementById("typec").href = "../../Main/types/advanture/";

// here u put the story  of the movie
document.getElementById("thestory").innerHTML = "بعد خسارة فانيسا (مورينا باكارين) ، حب حياته ، يجب على المرتزق المحطم للجدار الرابع ويد ويلسون الملقب بـ ديدبول (ريان رينولدز) أن يجمع فريقًا ويحمي راسيل كولينز المتحولة الشاب كامل الشكل المعروف باسم Firefist (جوليان دينيسون) من كابل (جوش برولين) ، إنسان آلي خطير وخطير من المستقبل ، ويجب أن يتعلم أيضًا أهم درس على الإطلاق: أن تكون جزءًا من عائلة مرة أخرى.";

// here put the movie img next to the table
document.getElementById("movieimg").src = "https://upload.wikimedia.org/wikipedia/ar/thumb/1/1a/Deadpool_two_ver15.jpg/260px-Deadpool_two_ver15.jpg";

/* here start the actor

!--the actors are sex and every one have actorjob and actorimg and actorname
and if u dont have the actor img then put this url on actorimg "../../Main/needed-photos/unkown-person.jfif"

*/

// the first actor a
document.getElementById("actornamea").innerHTML = " ديفيد ليتش";
document.getElementById("actorjoba").innerHTML = "المخرج";
document.getElementById("actorimga").src = "https://upload.wikimedia.org/wikipedia/commons/c/c4/David_Leitch_2014.jpg";
// the first actor b
document.getElementById("actornameb").innerHTML = "Ryan Reynolds";
document.getElementById("actorjobb").innerHTML = "Wade Wilson / Deadpool / Voice of Juggernaut";
document.getElementById("actorimgb").src = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Deadpool_2_Japan_Premiere_Red_Carpet_Ryan_Reynolds_%28cropped%29.jpg/220px-Deadpool_2_Japan_Premiere_Red_Carpet_Ryan_Reynolds_%28cropped%29.jpg";

// the first actor c
document.getElementById("actornamec").innerHTML = "Josh Brolin";
document.getElementById("actorjobc").innerHTML = "	Cable";
document.getElementById("actorimgc").src = "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c7/Josh_Brolin_LF.jpg/269px-Josh_Brolin_LF.jpg";

// the first actor d
document.getElementById("actornamed").innerHTML = "مورينا باكارين";
document.getElementById("actorjobd").innerHTML = "Vanessa";
document.getElementById("actorimgd").src = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e8/Morena_Baccarin_by_Gage_Skidmore.jpg/249px-Morena_Baccarin_by_Gage_Skidmore.jpg";

// the first actor e
document.getElementById("actornamee").innerHTML = "جوليان دينيسون";
document.getElementById("actorjobe").innerHTML = "Firefist";
document.getElementById("actorimge").src = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Julian_Dennison.jpg/245px-Julian_Dennison.jpg";

// the first actor f
document.getElementById("actornamef").innerHTML = "Zazie Beetz";
document.getElementById("actorjobf").innerHTML = "Domino";
document.getElementById("actorimgf").src = "https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/Zazie_Beetz_by_Gage_Skidmore_%28cropped%29.jpg/220px-Zazie_Beetz_by_Gage_Skidmore_%28cropped%29.jpg";

// here is the video trailer
document.getElementById("videotrailer").src = "https://www.youtube-nocookie.com/embed/D86RtevtfrA";

// here u put the link for downloading the movie
document.getElementById("downloadlink").href = "https://mega.nz/file/XcMmlRja#yTzxxi9p1whGkE_paEsWxmaA2fn_Qm3fCS7nnziwDT8";

// here u put the url for movie to show it on a iframe
document.getElementById("videomovie").src = "https://mega.nz/embed/XcMmlRja#yTzxxi9p1whGkE_paEsWxmaA2fn_Qm3fCS7nnziwDT8";